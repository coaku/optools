#!/bin/bash

INITBRIDGE=""

if [[ -e "./env.config" ]]
then
	eval `cat ./env.config`
fi

dpkg -i *.deb

if [[ $INITBRIDGE == "" ]]
then
	exit 0
fi

ovs-vsctl del-br $INITBRIDGE >/dev/null 2>&1
ovs-vsctl add-br $INITBRIDGE
ifconfig $INITBRIDGE up

