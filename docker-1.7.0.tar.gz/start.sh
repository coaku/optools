#!/bin/bash

CONFIGFILE="./docker.conf"

if [ $0 != "./start.sh" ]; then
   echo 'error! start.sh requires execution with the path of "./start.sh"'
   exit 1
fi

if [ ! -f $CONFIGFILE ]
then
  echo 'config file docker.conf not exists,exit!'
  exit 2
fi

ip link del docker0 >/dev/null 2>&1

numactl=`cat $CONFIGFILE | grep '^numactl --interleave=all$'`
args=`cat $CONFIGFILE | grep -v '^#' | grep -v 'numactl --interleave=all' | tr '\n' ' '`
echo load config file... args are $args
echo -n 'starting docker... '

$numactl ./docker-1.7.0 -d $args >>./docker.log 2>&1
