#!/bin/bash

ip link del docker0 >/dev/null 2>&1

if [[ ! -e "./env.config" ]]
then
	echo "ERROR: file ./env.config not found"
	exit 1
fi

eval `cat ./env.config`

if [[ $REGISTRY == "" ]]
then
	echo "ERROR: \$REGISTRY not set"
	exit 1
fi

if [[ $BRIDGE == "" ]]
then
	echo "ERROR: \$BRIDGE not set"
	exit 1
fi

if [[ $BINDTCP == "" ]]
then
	echo "ERROR: \$BINDTCP not set"
	exit 1
fi

if [[ $BINDSOCKET == "" ]]
then
	echo "ERROR: \$BINDSOCKET not set"
	exit 1
fi

/home/qboxserver/docker/docker \
 -d \
 --insecure-registry=${REGISTRY} \
 --bip=${BRIDGE} \
 -H ${BINDTCP} \
 -H ${BINDSOCKET} \
 >>/var/log/docker.log 2>&1
